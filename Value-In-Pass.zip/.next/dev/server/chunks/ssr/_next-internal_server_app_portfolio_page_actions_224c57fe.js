module.exports = [
"[project]/.next-internal/server/app/portfolio/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=_next-internal_server_app_portfolio_page_actions_224c57fe.js.map