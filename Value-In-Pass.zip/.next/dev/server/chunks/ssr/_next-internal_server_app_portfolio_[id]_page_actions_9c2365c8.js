module.exports = [
"[project]/.next-internal/server/app/portfolio/[id]/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=_next-internal_server_app_portfolio_%5Bid%5D_page_actions_9c2365c8.js.map